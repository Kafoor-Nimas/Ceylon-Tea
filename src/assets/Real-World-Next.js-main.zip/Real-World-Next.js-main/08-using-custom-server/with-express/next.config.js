module.exports = {
  useFileSystemPublicRoutes: false,
};
