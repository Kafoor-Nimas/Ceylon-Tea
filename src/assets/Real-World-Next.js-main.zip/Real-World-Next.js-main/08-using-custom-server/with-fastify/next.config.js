module.exports = {
  useFileSystemPublicRoutes: true,
};
